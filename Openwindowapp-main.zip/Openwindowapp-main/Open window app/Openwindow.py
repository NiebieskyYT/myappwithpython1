import tkinter as tk
from tkinter import *
import tkinter
print("Type something in to open a window!")
print("Example: 1234")
input("[Red]: ")
def input():
	if input == 1234:
		myWindow = tk.Tk()
		Label(myWindow, text="Hello, this is a window.").pack()
		myWindow.mainloop()
	else:
		print("ERROR! Try again")
		input("[Red]: ")
tk.Tk()
tk.mainloop()
